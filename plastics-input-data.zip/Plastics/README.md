Plastics
========

Input data for the [HEMCO](https://hemco.readthedocs.io/en/stable/) microplastic emissions module. See Fu et al. (2023) for details.

Source: All data were provided by [Yanxu Zhang](https://orcid.org/0000-0001-7770-3466)


Usage
-----

Place this directory and its contents in the HEMCO inputs directory of your GEOS-Chem input data (`ExtData/HEMCO`). The resulting file tree should look like this:

```
ExtData/
├── ...
├── HEMCO
│   ├── ...
│   ├── Plastics
│   │   ├── Agri
│   │   │   └── Fraction_agricultural_land_unitless.nc
│   │   ├── MMPW
│   │   │   └── MMPW_Borrelle_unitless.nc
│   │   ├── Ocean
│   │   │   ├── Int_plastic_con_2018.nc
│   │   │   ├── Surf_plastic_con_1x1_2018.nc
│   │   │   ├── create_plastic_con.m
│   │   │   ├── readme
│   │   │   └── surface_plastic_Mai_std.mat
│   │   ├── Resi
│   │   │   ├── glds00ag15.nc
│   │   │   └── readme_pdens_ascii_prod_lowres15_prod_00.txt
│   │   └── README.md
│   └── ...
└── ...
```


Contents
--------

### Agri

Gridded fraction of agricultural land. Fu et al. (2023) cite Lawrence et al. (2012) as the source of these data.

### MMPW

Gridded mismanaged plastic waste (MMPW) generation. Fu et al. (2023) cite Borelle et al. (2020) as the source of country-specific MMPW data, which they spatially interpolated based on gridded population density (see [Resi/](./Resi)).

### Ocean

Modelled ocean surface plastic concentration. Fu et al. (2023) cite Peng et al. (2021) and Zhang et al. (2023) as the source of these data.

Note: only the file `Int_plastic_con_2018.nc` is used by simulations.

### Resi

Gridded world population density from GPWv3 (CIESIN 2005).


References
----------

Borrelle, S. B., Ringma, J., Law, K. L., Monnahan, C. C., Lebreton, L., McGivern, A., Murphy, E., Jambeck, J., Leonard, G. H., Hilleary, M. A., Eriksen, M., Possingham, H. P., De Frond, H., Gerber, L. R., Polidoro, B., Tahir, A., Bernard, M., Mallos, N., Barnes, M., & Rochman, C. M. (2020). Predicted growth in plastic waste exceeds efforts to mitigate plastic pollution. Science, 369(6510), 1515–1518. https://doi.org/10.1126/science.aba3656

CIESIN (Center For International Earth Science Information Network)-Columbia University. (2005). Gridded Population of the World, Version 3 (GPWv3): Population Density Grid [Data set]. NASA Socioeconomic Data and Applications Center (SEDAC). https://www.earthdata.nasa.gov/data/catalog/sedac-ciesin-sedac-gpwv3-popdens-3.0

Fu, Y., Pang, Q., Ga, S. L. Z., Wu, P., Wang, Y., Mao, M., Yuan, Z., Xu, X., Liu, K., Wang, X., Li, D., & Zhang, Y. (2023). Modeling atmospheric microplastic cycle by GEOS-Chem: An optimized estimation by a global dataset suggests likely 50 times lower ocean emissions. *One Earth*, *6*(6), 705–714. https://doi.org/10.1016/j.oneear.2023.05.012

Lawrence, P. J., Feddema, J. J., Bonan, G. B., Meehl, G. A., O’Neill, B. C., Oleson, K. W., Levis, S., Lawrence, D. M., Kluzek, E., Lindsay, K., & Thornton, P. E. (2012). Simulating the Biogeochemical and Biogeophysical Impacts of Transient Land Cover Change and Wood Harvest in the Community Climate System Model (CCSM4) from 1850 to 2100. Journal of Climate, 25(9), 3071–3095. https://doi.org/10.1175/JCLI-D-11-00256.1

Peng, Y., Wu, P., Schartup, A. T., & Zhang, Y. (2021). Plastic waste release caused by COVID-19 and its fate in the global ocean. Proceedings of the National Academy of Sciences, 118(47), e2111530118. https://doi.org/10.1073/pnas.2111530118

Zhang, Y., Wu, P., Xu, R., Wang, X., Lei, L., Schartup, A. T., Peng, Y., Pang, Q., Wang, X., Mai, L., Wang, R., Liu, H., Wang, X., Luijendijk, A., Chassignet, E., Xu, X., Shen, H., Zheng, S., & Zeng, E. Y. (2023). Plastic waste discharge to the global ocean constrained by seawater observations. Nature Communications, 14(1), 1372. https://doi.org/10.1038/s41467-023-37108-5
