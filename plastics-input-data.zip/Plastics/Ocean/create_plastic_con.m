clear

load('surface_plastic_Mai_std.mat');

geodir = '/data3/home/yxzhang/IGSM/regrid/';
lat_igsm = ncread(strcat(geodir,'grid_igsm.nc'),'Y');
lon_igsm = ncread(strcat(geodir,'grid_igsm.nc'),'X');

nccreate('Int_plastic_con_2018.nc','int_plastic','Dimensions', {'lon',144,'lat',90}, ...
         'FillValue','disable');
nccreate('Int_plastic_con_2018.nc','lon', 'Dimensions',{'lon',144}, ...
         'FillValue','disable');
nccreate('Int_plastic_con_2018.nc','lat', 'Dimensions',{'lat',90}, ...
         'FillValue','disable');

ncwrite('Int_plastic_con_2018.nc','lat',lat_igsm);
ncwrite('Int_plastic_con_2018.nc','lon',lon_igsm);
ncwrite('Int_plastic_con_2018.nc','int_plastic',data_model);

ncwriteatt('Int_plastic_con_2018.nc','lat','units','degrees_north');
ncwriteatt('Int_plastic_con_2018.nc','lon','units','degrees_east');
ncwriteatt('Int_plastic_con_2018.nc','int_plastic','units','unitless');
